public class Payments {
    
}

public class DebitCardPayment extends Payments {
    // Logic
}

public class CreditCardPayment extends Payments {
    // Logic
}

public class CashPayment extends Logic {
    // Logic
}