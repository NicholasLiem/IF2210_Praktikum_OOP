public interface Taxable {
    double calculateTax();
}
