public class PaymentProcessor {
    Payments paymentType selected;
    public void process(int totalPrice){
        // Pakai logic masing-masing dari paymentType yang di select;
        // Logic
    }

    // public void processPaymentWithDebitCard(double amount) {
    //     // Process payment logic
    //     System.out.println("Payment processed successfully with debit card: $" + amount);
    // }
 
 
    // public void processPaymentWithCreditCard(double amount) {
    //     // Process payment logic
    //     System.out.println("Payment processed successfully with credit card: $" + amount);
    // }
 
 
    // public void processPaymentWithCash(double amount) {
    //     // Process payment logic
    //     System.out.println("Payment processed successfully with cash: $" + amount);
    // }
 }