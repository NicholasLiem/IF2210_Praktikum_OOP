public interface  Observer {
    void notifyUpdate();
}
